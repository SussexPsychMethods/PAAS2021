#' Dummy survey data
#' @format a tibble with 25 rows and 12 columns
"survey_data"


#' Stars Wars data
#'
#' A subset of the starwars data set from the dplyr package
"starwars2"

